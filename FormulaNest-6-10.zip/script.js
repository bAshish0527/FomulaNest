function openClassPage(classNumber) {
    window.location.href = `notes.html?class=${classNumber}`;
}

function registerServiceWorker() {
    const isSupportedProtocol = window.location.protocol === "https:" || window.location.hostname === "localhost";
    if ("serviceWorker" in navigator && isSupportedProtocol) {
        navigator.serviceWorker.register("sw.js").catch(function () {
            // App remains functional even if service worker registration fails.
        });
    }
}

function setPageTitleFromClass() {
    const titleElement = document.getElementById("page-title");
    if (!titleElement) {
        return;
    }

    const params = new URLSearchParams(window.location.search);
    const classNumber = params.get("class");

    if (classNumber) {
        titleElement.textContent = `📚 Class ${classNumber} FormulaNest`;
    }
}

function showNotes(subject) {
    let content = document.getElementById("content");
    const params = new URLSearchParams(window.location.search);
    const classNumber = params.get("class");

    if (!content) {
        return;
    }

    if (subject === "physics") {
        if (classNumber === "6") {
            content.innerHTML = `
                <h2>Physics Notes - Class 6</h2>
                <h3>Motion & Measurement</h3>
                <p>Speed = Distance / Time</p>
                <p>Distance = Speed × Time</p>
                <p>Time = Distance / Speed</p>
            `;
        } else if (classNumber === "7") {
            content.innerHTML = `
                <h2>Physics Notes - Class 7</h2>
                <h3>Motion & Time</h3>
                <p>Speed = Distance / Time</p>
                <p>Average Speed = Total Distance / Total Time</p>
                <h3>Work & Energy</h3>
                <p>Work = Force × Distance</p>
                <p>Power = Work / Time</p>
            `;
        } else if (classNumber === "8") {
            content.innerHTML = `
                <h2>Physics Notes - Class 8</h2>
                <h3>Force & Pressure</h3>
                <p>Force = Mass × Acceleration</p>
                <p>Pressure = Force / Area</p>
                <h3>Work & Energy</h3>
                <p>Work = Force × Distance</p>
                <p>Power = Work / Time</p>
            `;
        } else if (classNumber === "9") {
            content.innerHTML = `
                <h2>Physics Notes - Class 9</h2>
                <h3>Motion</h3>
                <p>Speed = Distance / Time</p>
                <p>Velocity = Displacement / Time</p>
                <p>Acceleration = (v − u) / t</p>
                <h3>Equations of Motion</h3>
                <p>v = u + at</p>
                <p>s = ut + 1/2at²</p>
                <p>v² = u² + 2as</p>
                <h3>Laws of Motion</h3>
                <p>Force = ma</p>
                <p>Momentum = mv</p>
                <p>Impulse = Ft</p>
                <h3>Gravitation</h3>
                <p>F = Gm₁m₂ / r²</p>
                <p>g = GM / R²</p>
                <p>Weight = mg</p>
                <h3>Work, Energy & Power</h3>
                <p>Work = Fd cosθ</p>
                <p>Kinetic Energy = 1/2mv²</p>
                <p>Potential Energy = mgh</p>
                <p>Power = Work / Time</p>
                <h3>Density & Pressure</h3>
                <p>Density = Mass / Volume</p>
                <p>Pressure = Force / Area</p>
            `;
        } else if (classNumber === "10") {
            content.innerHTML = `
                <h2>Physics Notes - Class 10</h2>
                <h3>Electricity</h3>
                <p>Current: I = Q / t</p>
                <p>Voltage: V = W / Q</p>
                <p>Ohm's Law: V = IR</p>
                <p>Resistance: R = ρL / A</p>
                <h3>Electric Power</h3>
                <p>Power = VI</p>
                <p>P = I²R</p>
                <p>P = V² / R</p>
                <p>Energy = Power × Time</p>
                <h3>Magnetism</h3>
                <p>Force on conductor: F = BIL sinθ</p>
                <h3>Light (Reflection & Refraction)</h3>
                <p>Mirror/Lens Formula: 1/f = 1/v + 1/u</p>
                <p>Magnification: m = v / u</p>
                <p>Magnification: m = h₂ / h₁</p>
                <h3>Waves</h3>
                <p>v = fλ</p>
                <p>Frequency = 1 / Time period</p>
            `;
        } else {
            content.innerHTML = `
                <h2>Physics Notes</h2>
                <p>Please select a class from the dashboard to view class-wise physics formulas.</p>
            `;
        }
    } else if (subject === "maths") {
        if (classNumber === "6") {
            content.innerHTML = `
                <h2>Maths Notes - Class 6</h2>
                <h3>Numbers</h3>
                <p>HCF × LCM = Product of two numbers</p>
                <p>LCM of fractions = LCM of numerators / HCF of denominators</p>
                <h3>Fractions</h3>
                <p>a/b + c/d = (ad + bc)/bd</p>
                <p>a/b − c/d = (ad − bc)/bd</p>
                <p>a/b × c/d = ac/bd</p>
                <p>a/b ÷ c/d = a/b × d/c</p>
                <h3>Basic Geometry</h3>
                <p>Perimeter of rectangle = 2(l + b)</p>
                <p>Area of rectangle = l × b</p>
                <p>Area of square = a²</p>
                <p>Perimeter of square = 4a</p>
            `;
        } else if (classNumber === "7") {
            content.innerHTML = `
                <h2>Maths Notes - Class 7</h2>
                <h3>Integers</h3>
                <p>a − (−b) = a + b</p>
                <p>(−a)(−b) = ab</p>
                <p>(−a)(b) = −ab</p>
                <h3>Ratio & Proportion</h3>
                <p>a : b = c : d ⇒ ad = bc</p>
                <h3>Simple Interest</h3>
                <p>SI = (P × R × T)/100</p>
                <h3>Lines & Angles</h3>
                <p>Linear pair = 180°</p>
                <p>Vertically opposite angles are equal</p>
            `;
        } else if (classNumber === "8") {
            content.innerHTML = `
                <h2>Maths Notes - Class 8</h2>
                <h3>Algebraic Identities</h3>
                <p>(a + b)² = a² + 2ab + b²</p>
                <p>(a − b)² = a² − 2ab + b²</p>
                <p>a² − b² = (a − b)(a + b)</p>
                <h3>Percentage</h3>
                <p>Percentage = (Value / Total) × 100</p>
                <h3>Mensuration</h3>
                <p>Area of trapezium = 1/2 (a + b)h</p>
                <p>Volume of cube = a³</p>
                <p>Volume of cuboid = lbh</p>
                <h3>Exponents</h3>
                <p>aᵐ × aⁿ = aᵐ⁺ⁿ</p>
                <p>aᵐ / aⁿ = aᵐ⁻ⁿ</p>
                <p>(aᵐ)ⁿ = aᵐⁿ</p>
            `;
        } else if (classNumber === "9") {
            content.innerHTML = `
                <h2>Maths Notes - Class 9</h2>
                <h3>Heron's Formula</h3>
                <p>Area = √[s(s−a)(s−b)(s−c)]</p>
                <p>s = (a + b + c)/2</p>
                <h3>Statistics</h3>
                <p>Mean = Σx / n</p>
                <h3>Coordinate Geometry</h3>
                <p>Distance = √[(x₂−x₁)² + (y₂−y₁)²]</p>
                <p>Midpoint = [(x₁+x₂)/2 , (y₂+y₁)/2]</p>
                <h3>Triangles</h3>
                <p>Angle sum = 180°</p>
                <h3>Circles</h3>
                <p>Circumference = 2πr</p>
                <p>Area = πr²</p>
            `;
        } else if (classNumber === "10") {
            content.innerHTML = `
                <h2>Maths Notes - Class 10</h2>
                <h3>Quadratic Equations</h3>
                <p>Discriminant: D = b² − 4ac</p>
                <p>D &gt; 0 → real &amp; distinct</p>
                <p>D = 0 → equal roots</p>
                <p>D &lt; 0 → no real roots</p>
                <h3>Arithmetic Progression (AP)</h3>
                <p>nth term: aₙ = a + (n−1)d</p>
                <p>Sum: Sₙ = n/2 [2a + (n−1)d]</p>
                <h3>Trigonometry</h3>
                <p>sinθ = Perpendicular / Hypotenuse</p>
                <p>cosθ = Base / Hypotenuse</p>
                <p>tanθ = Perpendicular / Base</p>
                <p>sin²θ + cos²θ = 1</p>
                <p>1 + tan²θ = sec²θ</p>
                <p>1 + cot²θ = cosec²θ</p>
                <h3>Standard Values</h3>
                <p>0°: sinθ = 0, cosθ = 1, tanθ = 0</p>
                <p>30°: sinθ = 1/2, cosθ = √3/2, tanθ = 1/√3</p>
                <p>45°: sinθ = 1/√2, cosθ = 1/√2, tanθ = 1</p>
                <p>60°: sinθ = √3/2, cosθ = 1/2, tanθ = √3</p>
                <p>90°: sinθ = 1, cosθ = 0, tanθ = ∞</p>
                <h3>Circles</h3>
                <p>Tangent ⟂ Radius</p>
                <h3>Surface Areas & Volumes</h3>
                <p>Cylinder Volume = πr²h</p>
                <p>Cylinder CSA = 2πrh</p>
                <p>Cylinder TSA = 2πr(r + h)</p>
                <p>Cone Volume = 1/3 πr²h</p>
                <p>Cone CSA = πrl</p>
                <p>Sphere Volume = 4/3 πr³</p>
                <p>Sphere Surface Area = 4πr²</p>
                <h3>Statistics</h3>
                <p>Mean = Σfx / Σf</p>
                <h3>Probability</h3>
                <p>Probability = Favorable outcomes / Total outcomes</p>
            `;
        } else {
            content.innerHTML = `
                <h2>Maths Notes</h2>
                <p>Please select a class from the dashboard to view class-wise maths formulas.</p>
            `;
        }
    } else if (subject === "chemistry") {
        if (classNumber === "6") {
            content.innerHTML = `
                <h2>Chemistry Notes - Class 6</h2>
                <h3>Matter</h3>
                <p>Matter = Anything that has mass + occupies space</p>
                <h3>States of Matter</h3>
                <p>Solid → Fixed shape &amp; volume</p>
                <p>Liquid → Fixed volume, no fixed shape</p>
                <p>Gas → No fixed shape &amp; volume</p>
                <h3>Changes</h3>
                <p>Physical change → No new substance</p>
                <p>Chemical change → New substance formed</p>
            `;
        } else if (classNumber === "7") {
            content.innerHTML = `
                <h2>Chemistry Notes - Class 7</h2>
                <h3>Physical &amp; Chemical Changes</h3>
                <p>Rusting requires: Oxygen + Water</p>
                <h3>Acids &amp; Bases (Basic)</h3>
                <p>Acid → Sour (e.g., lemon)</p>
                <p>Base → Bitter, soapy</p>
            `;
        } else if (classNumber === "8") {
            content.innerHTML = `
                <h2>Chemistry Notes - Class 8</h2>
                <h3>Atomic Structure</h3>
                <p>Atom = Proton (+) + Neutron (0) + Electron (−)</p>
                <h3>Valency</h3>
                <p>Valency = Combining capacity of atom</p>
                <h3>Chemical Formula Writing</h3>
                <p>Cross method: Ca²⁺ + Cl⁻ → CaCl₂</p>
                <h3>Combustion</h3>
                <p>Fuel + O₂ → CO₂ + Heat + Light</p>
                <h3>Acids, Bases, Salts</h3>
                <p>Acid + Base → Salt + Water (Neutralization)</p>
            `;
        } else if (classNumber === "9") {
            content.innerHTML = `
                <h2>Chemistry Notes - Class 9</h2>
                <h3>Atomic Structure</h3>
                <p>Atomic Number: Z = Number of protons = electrons</p>
                <p>Mass Number: A = Protons + Neutrons</p>
                <h3>Mole Concept</h3>
                <p>1 mole = 6.022 × 10²³ particles</p>
                <p>Moles = Given mass / Molar mass</p>
                <p>Number of particles = Moles × Avogadro number</p>
                <h3>Law of Conservation of Mass</h3>
                <p>Total mass of reactants = Total mass of products</p>
                <h3>Density</h3>
                <p>Density = Mass / Volume</p>
            `;
        } else if (classNumber === "10") {
            content.innerHTML = `
                <h2>Chemistry Notes - Class 10</h2>
                <h3>Chemical Reactions</h3>
                <p>Combination: A + B → AB</p>
                <p>Decomposition: AB → A + B</p>
                <p>Displacement: A + BC → AC + B</p>
                <h3>Balancing Equations</h3>
                <p>Law: Atoms must be equal on both sides</p>
                <h3>Acids, Bases, Salts</h3>
                <p>pH &lt; 7 → Acid</p>
                <p>pH = 7 → Neutral</p>
                <p>pH &gt; 7 → Base</p>
                <h3>Metals &amp; Non-Metals</h3>
                <p>Metals + Oxygen → Metal Oxide</p>
                <p>Metals + Water → Metal Hydroxide + H₂</p>
                <h3>Electrolysis</h3>
                <p>Anode → Oxidation</p>
                <p>Cathode → Reduction</p>
                <h3>Redox Reactions</h3>
                <p>Oxidation = Loss of electrons</p>
                <p>Reduction = Gain of electrons</p>
                <h3>Carbon Compounds</h3>
                <p>Covalent Bond: Sharing of electrons</p>
                <p>Alkanes → CₙH₂ₙ₊₂</p>
                <p>Alkenes → CₙH₂ₙ</p>
                <p>Alkynes → CₙH₂ₙ₋₂</p>
                <h3>Functional Groups</h3>
                <p>–OH → Alcohol</p>
                <p>–COOH → Carboxylic acid</p>
                <p>–CHO → Aldehyde</p>
                <h3>Periodic Table Trends</h3>
                <p>Atomic Size: Increases ↓, Decreases →</p>
                <p>Metallic Character: Increases ↓, Decreases →</p>
                <h3>Important Gas Laws</h3>
                <p>Boyle's Law: P ∝ 1/V</p>
            `;
        } else {
            content.innerHTML = `
                <h2>Chemistry Notes</h2>
                <p>Please select a class from the dashboard to view class-wise chemistry formulas.</p>
            `;
        }
    }
}

setPageTitleFromClass();
registerServiceWorker();
